<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Money extends Model
{
     public function getRouteKeyName() {
          return 'slug';
      }
      public function Bill(){
          return $this->belongsTo('App\Models\Bill');
     }
    use HasFactory;
    protected $table='Money';
    protected $fillable=[
         
         'Loan',
         'Cash',
         'Pre_Blance',
         'Total_Blance',
         'Bill_ID',
         'Date',
         'Trash',
    ];

    public function setPreBlance(){
     $this->Pre_Blance=Money::where('Bill_ID',$this->Bill_ID)->sum('Loan');
         
  }

    
   
     

}
