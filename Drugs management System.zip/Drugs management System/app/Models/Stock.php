<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Stock extends Model
{
   
    public function AddCompany(){
    	return $this->belongsTo('App\Models\AddCompany');
    }
    public function Bill()
{
    return $this->hasMany('App\Models\Bill');
}

    use HasFactory;
    protected $table='Stock';
    protected $fillable=[
    'DrugName',
    'Price',
     'Quantity',
     'Category',
     'EntryDate',
     'ExpireDate',
     'AddCompany_ID',
     'Trash',
];}
