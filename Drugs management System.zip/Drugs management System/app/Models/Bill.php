<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bill extends Model
{
    
    public function Money()
{
    return $this->hasMany('App\Models\Money');
}
    public function Customer(){
    	return $this->belongsTo('App\Models\Customer');
    }
    public function Stock(){
    	return $this->belongsTo('App\Models\Stock');
    }


    use HasFactory;
    protected $table='Bill';
    protected $fillable=[
        'DrugName',
        'Quantity',
         'Price',
         'Discount',
         'Stock_ID',
         'Loan',
         'Dilevared_By',
         'Customer_ID',
         'Cash',
         'Total',
         'Date',
         'Trash',

    ];
    public function SetTotal(){
        $this->Total=($this->Price*$this->Quantity)-$this->Discount;
     }
    

}
