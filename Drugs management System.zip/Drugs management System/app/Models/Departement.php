<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Departement extends Model
{
  public function getRouteKeyName() {
    return 'slug';
}
  public function Employee(){
    return $this->belongsTo('App\Models\Employee');
  }

    use HasFactory;
    protected $table='Departement';
    protected $fillable=[
      'DepartementName', 
      'Trash',
    ];
     
}
