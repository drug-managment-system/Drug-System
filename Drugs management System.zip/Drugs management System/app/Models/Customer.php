<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
  public function getRouteKeyName() {
    return 'slug';
}
public function Bill()
{
    return $this->hasMany('App\Models\Bill');
}
  
  use HasFactory;
    protected $table='Customer';
    protected $fillable=[
      'Name',
      'Photo',
      'FatherName',
      'Address',
      'Email',
      'Tash',
    ];
}
