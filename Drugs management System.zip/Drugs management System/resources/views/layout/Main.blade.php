@include('layout.head')
@include('layout.header')
@yield('contents')
@include('layout.footer')