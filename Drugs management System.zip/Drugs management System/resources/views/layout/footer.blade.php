
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-3 mb-4 mb-lg-0">

            <div class="block-7">
              <h3 class="footer-heading mb-4">زموږ په اړه</h3>
              <p> موژ ټوله ټیم د کندهار پوهنتون محصیلن یو دا زموژ داخیري کال پروژه ده چي په ګډه مو تر سره کړه</p>
            </div>

          </div>
          <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
            <h3 class="footer-heading mb-4">Quick Links</h3>
            <ul class="list-unstyled">
            <li><a href='Employees'><b>Employees</b></a></li>
             
               <li><a href='Stock'><b> Stocks</b></a></li>
               <li><a href='Bills'><b>Bills</b></a></li>
               <li><a href='Expenses'>Expenses</li>
            </ul>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="block-5 mb-5">
              <h3 class="footer-heading mb-4">Companey Address  </h3>
              <ul class="list-unstyled">
                <li class="address">غزنی بوستان پلازه دویم منزل د دسیلاب او کاري ټیم کمپني </li>
                <li class="phone"><a href="tel://23923929210">0702370294 / 0794741077</a></li>
                <li class="email">sayednazimselab2021@gmail.com</li>
              </ul>
            </div>


          </div>
        </div>
        

        </div>
      </div>
    </footer>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>

</body>

</html