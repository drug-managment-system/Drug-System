
<?php $__env->startSection('contents'); ?>
 
<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;}
th, td {
    padding: 0.5px;}
 
</style>

</head>
<body  >
<div   align="right" style="background-color:black"  >
 
     <input type="search" placeholder="search Customer"><input type="submit" class="btn btn-danger" value="Search">
      <a href='index'>Home</a>  
</div> <br><br> 
 
 <h1   align="center"> <b>Employees</b> </h1> 
 <div  style="margin:35px;" align="right"> <a href='index' style="background-color:green"  >GO Back</a> </div>
 <a href='AddEmployee' style="background-color:green" >Add New Employee </a>

  
              
              
   
<form   >
 
<table  style="width:95%"  align="center">
    <tr>
         <th>ID</th>
         <th>Name</th>
         <th>FatherName</th>
         <th>Address</th>
         <th>Email</th>
         <th>Salary</th>
         <th> Job </th>
         <th>IncomeDate</th>
         <th>DepID</th>
         <th>Edit row</th>
         <th>Delete row</th>
    </tr>
    
      
     <?php $__currentLoopData = $Employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
           <td><?php echo e($item->id); ?></td>
           <td><?php echo e($item->Name); ?></td>
           <td><?php echo e($item->FatherName); ?></td>
           <td><?php echo e($item->Address); ?></td>
           <td><?php echo e($item->Email); ?></td>
           <td><?php echo e($item->Salary); ?></td>
           <td><?php echo e($item->Job); ?></td>
           <td><?php echo e($item->IncomeDate); ?></td>
           <td><?php echo e($item->DepID); ?></td>
           <td>
        
 <a href="<?php echo e(url('Emp_Edit/'.$item->id)); ?>" class="btn btn-primary btn-sm">Edit</a>     
           </td>
           <td>
 <a href="<?php echo e(url('Emp_Delete/'.$item->id)); ?>" class="btn btn_danger btn_sm">Emp_Delete</a>
           </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
      </table> 
 </form>     
</body>
<?php echo $__env->make('Layout.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Final Project\mylaravel\resources\views/Employees.blade.php ENDPATH**/ ?>