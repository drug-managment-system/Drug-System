         
<body style="background-color:lightgrey">

        <h1  align="center"> Now you can add new Bills </h1> 

          <form class="col-md-12"   action="\store3" method="POST" align="center" >
          <?php echo csrf_field(); ?>
     
          <div  style="margin:40px;" align="right" > <a href='Bills' style="background-color:green"  >GO Back</a> </div>
            
                <lable> DrugName </lable><br>
                 <input type="text" name="DrugName" class="form-control" style="width:70%" > <br>
               
                <lable> Quantity </lable><br>
                 <input type="number" name="Quantity"  style="width:70%" > <br>
              
                    <lable> Price   </lable><br>
                 <input type="number" name="Price" class="form-control" style="width:70%" > <br>
               
               <lable> Discount </lable><br>
                 <input type="number" name="Discount" class="form-control" style="width:70%" > <br>
                
                 <lable> Total</lable><br>
                 <input type="number" name="Total" class="form-control" style="width:70%" > <br>
                
                 <lable> Stock ID</lable><br>
                 <input type="number" name="Stock_ID" class="form-control" style="width:70%" > <br>
                 
                 <lable> Pre_Blance</lable><br>
                 <input type="number" name="Pre_Blance" class="form-control" style="width:70%" > <br>
               
                 <lable> Customer_ID</lable><br>
                 <input type="number" name="Customer_ID" class="form-control" style="width:70%" > <br>
              
                 <lable> Loan</lable><br>
                 <input type="number" name="Loan" class="form-control" style="width:70%" > <br>
                
                 <lable> Cash</lable><br>
                 <input type="number" name="Cash" class="form-control" style="width:70%" > <br><
               
                 <lable>Dilevared_By</lable><br>
                 <input type="text" name="Dilevared_By" class="form-control" style="width:70%" > <br>
                
                 <lable> Date </lable><br>
                 <input type="date" name="Date" class="form-control" style="width:70%" > <br>
               
           
                  <button style="width:10%;background-color:Magenta " type="submit"  name="save" class="btn btn-primary"> Save</button>
            </div>
               </form>
               </body><?php /**PATH E:\Final Project\mylaravel\resources\views/\AddBill.blade.php ENDPATH**/ ?>