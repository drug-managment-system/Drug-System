<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    width:30%;
    border-collapse: collapse;}
th, td {
    padding:  5px;}
</style>
</head>
<br>  <h1   align="center"> Now you can Edit this Note</h1>
<body style="background-color:lightgrey" >
 
<form action="<?php echo e(url('update-Notes/'.$Notes->id)); ?>Notes" method="POST">

<?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
      
          
                      
      <h1 align="center"  >___________________________________________________________</h1> 
   
    <table  align="center">  
            <tr>
             <td>
          <label for="" align="rigth">Amount </label><br>
          <input type="number" name="Amount" value="<?php echo e($Notes->Amount); ?>" class="form-control">
                     </td>
                     </tr>
                     <tr>
                    <td>
                    <label  for="">Details</label><br>
                    <input type="text" name="Detail" value="<?php echo e($Notes->Detail); ?>" class="form-control">
                     
                    </td>
                 </tr>
                 <tr>
                    <td>
                   <label for="">Date </label><br>
                   <input type="date" name="Date" value="<?php echo e($Notes->Date); ?>" class="form-control">
                      
                    </td> 
                    </tr>
                    
                    </table> 
                  
             
          <br> <div class="form-group mb-3" align="center">
           <button type="submit" class="btn btn-primary"  style="background-color:green">Update</button>
          </div> 
         <h1 align="center" >___________________________________________________________</h1> 
                   
         </form>                       
 





 








                       
                         
                     
                         
                           

                    
<?php /**PATH E:\Final Project\mylaravel\resources\views/Notes_Edit.blade.php ENDPATH**/ ?>