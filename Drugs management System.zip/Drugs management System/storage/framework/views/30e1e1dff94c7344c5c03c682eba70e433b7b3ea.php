 
<body>
 
 <select onchange="changeLanguage(this.value)">
 
</select>
 
<h1><?php echo e(__('messages.title')); ?></h1>
 
<body>
 
<script>
function changeLanguage(lang){
    window.location='<?php echo e(url("change-language")); ?>/'+lang;
}
</scritp><?php /**PATH E:\Final Project\Drugs management System\resources\views/Lang.blade.php ENDPATH**/ ?>