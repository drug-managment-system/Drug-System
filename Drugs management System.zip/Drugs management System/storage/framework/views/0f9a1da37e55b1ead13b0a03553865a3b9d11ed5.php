<form action="<?php echo e(url('update-Stock/'.$Stock->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group mb-3">
                            <label for="">DrugName</label>
                            <input type="text" name="DrugName" value="<?php echo e($Stock->DrugName); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Quantity</label>
                            <input type="number" name="Quantity" value="<?php echo e($Stock->Quantity); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">buingPrice</label>
                            <input type="number" name="BuingPrice" value="<?php echo e($Stock->BuingPrice); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">EntryDate</label>
                            <input type="date" name="EntryDate" value="<?php echo e($Stock->EntryDate); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">ExpireDate</label>
                            <input type="date" name="ExpireDate" value="<?php echo e($Stock->ExpireDate); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Category</label>
                            <input type="text" name="Category" value="<?php echo e($Stock->Category); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update Stock</button>
                        </div>

                    </form>


                    
<?php /**PATH C:\LaravelProject\mylaravel\resources\views/Stock_Edit.blade.php ENDPATH**/ ?>