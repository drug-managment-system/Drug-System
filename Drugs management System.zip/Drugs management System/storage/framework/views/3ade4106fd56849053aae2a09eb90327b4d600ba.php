 
                
<body style="background-color:lightgrey">
        <h1   align="center">Now you can add new Money</h1> 

          <form class="col-md-12"   action="\store13" method="POST" align="center" >
          <?php echo csrf_field(); ?>
          
        
          <div  style="margin:40px;" align="right" > <a href='Money' style="background-color:red"  >GO Back</a> </div>
         
 
 
                  <lable> Total_Blance</lable><br>
                 <input type="number" name="Total_Blance" class="form-control" style="width:70%" > <br><br>
                 
                    <lable> Pre_Blance</lable><br>
                 <input type="number" name="Pre_Blance" class="form-control" style="width:70%" > <br><br>
                 
                 <lable> Bill_ID</lable><br>
                 <input type="number" name="Bill_ID" class="form-control" style="width:70%" > <br><br>
                 
               <lable> Loan</lable><br>
                 <input type="number" name="Loan" class="form-control" style="width:70%" > <br><br>
                  
                 <lable> Cash</lable><br>
                 <input type="number" name="Cash" class="form-control"style="width:70%" > <br><br>
                 
                 <lable> Date </lable> <br>
                 <input type="date" name="Date" class="form-control" style="width:70%" > <br><br>
                 
                  <button style="width:10%;background-color:Magenta " type="submit"  name="save" class="btn btn-primary"> Save</button>
            </div>
               </form>
               </body><?php /**PATH E:\Final Project\mylaravel\resources\views/\AddMoney.blade.php ENDPATH**/ ?>