
<?php $__env->startSection('contents'); ?>
 
<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;}
th, td {
    padding: 0.5px;}
 
</style>

</head>
<body  >
<div   align="right" style="background-color:black"  >
 
     <input type="search" placeholder="search Customer"><input type="submit" class="btn btn-danger" value="Search">
      <a href='index'>Home</a>  
</div> <br><br> 
 
 <h1   align="center"> <b>Expenses</b> </h1> 
 <div  style="margin:35px;" align="right"> <a href='index' style="background-color:green"  >GO Back</a> </div>
 <a href='AddExpenses' style="background-color:green" >Add New Expenses </a>


   

<form  >
 
<table  style="width:95%"  align="center">
    <tr>
         <th>ID</th>
         <th>Amount</th>
         <th>Detail</th>
         <th>Dep_ID</th>
         <th>Date</th>
         <th>Edit row</th>
         <th>Delete row</th>
          
    </tr>
     <?php $__currentLoopData = $Expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
           <td><?php echo e($item->id); ?></td>
           <td><?php echo e($item->Amount); ?></td>
           <td><?php echo e($item->Detail); ?></td>
           <td><?php echo e($item->Dep_ID); ?></td>
           
           <td><?php echo e($item->Date); ?></td>
          
           <td>
 <a href="<?php echo e(url('Exp_Edit/'.$item->id)); ?>" class="btn btn-primary btn-sm">Edit</a>     
           </td>
           <td>
 <a href=" url('Exp_Delete/'.$item->id) }}" class="btn btn_danger btn_sm">Delete</a>
           </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
      </table> 
 </form>     
</body>
                    

<?php echo $__env->make('Layout.Main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Final Project\mylaravel\resources\views/Expensess.blade.php ENDPATH**/ ?>