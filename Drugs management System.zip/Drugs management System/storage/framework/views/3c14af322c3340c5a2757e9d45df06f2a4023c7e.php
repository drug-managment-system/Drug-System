<form action="<?php echo e(url('update-Dep/'.$Departement->id)); ?>Departement" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group mb-3">
                            <label for="">DepartementName</label>
                            <input type="text" name="DepartementName" value="<?php echo e($Departement->DepartementName); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update Departement</button>
                        </div>

                    </form>


                    
<?php /**PATH C:\LaravelProject\mylaravel\resources\views/Dep_Edit.blade.php ENDPATH**/ ?>