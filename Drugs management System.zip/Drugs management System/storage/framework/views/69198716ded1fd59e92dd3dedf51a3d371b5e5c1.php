 
                
<body style="background-color:lightgrey">
        <h1   align="center">Now you can add new Departement </h1> 

          <form class="col-md-12"   action="\store4" method="POST" align="center" >
          <?php echo csrf_field(); ?>
          
        
          <div  style="margin:40px;" align="right" > <a href='Departement' style="background-color:green"  >GO Back</a> </div>
        
                <lable> DepartementName :</lable> <br>
                 <input type="text" name="DepartementName" class="form-control" style="width:70%"><br><br>
            
                 <button style="width:10%;background-color:Magenta " type="submit"  name="save" class="btn btn-primary"> Save</button>
            </div>
             


               </form>
               </body><?php /**PATH E:\Final Project\mylaravel\resources\views/\AddDepartement.blade.php ENDPATH**/ ?>