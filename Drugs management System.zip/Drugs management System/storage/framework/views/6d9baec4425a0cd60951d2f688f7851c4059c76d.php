<form action="<?php echo e(url('update-Sale/'.$Sale->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group mb-3">
                            <label for="">DrugName</label>
                            <input type="text" name="DrugName" value="<?php echo e($Sale->DrugName); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Quantity</label>
                            <input type="number" name="Quantity" value="<?php echo e($Sale->Quantity); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Price</label>
                            <input type="number" name="Price" value="<?php echo e($Sale->Price); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Total</label>
                            <input type="number" name="Total" value="<?php echo e($Sale->Total); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Descount</label>
                            <input type="number" name="Descount" value="<?php echo e($Sale->Descount); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Date</label>
                            <input type="date" name="Date" value="<?php echo e($Sale->Date); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Bill_ID</label>
                            <input type="number" name="Bill_ID" value="<?php echo e($Sale->Bill_ID); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update Sale</button>
                        </div>

                    </form>


                    
<?php /**PATH C:\LaravelProject\mylaravel\resources\views/Sale_Edit.blade.php ENDPATH**/ ?>