<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;}
th, td {
    padding: 1px;}
</style>
</head>
<body style="background-color:lightgrey">
  

 <h1   align="center">Bills page  </h1>      
<table   style="width:100%"  align="center">
 <tr>
      <th><a href='Customer'>مشتریان</a></th>
      <th><a href='Stock'>درمل</a> </th>
      <th><a href='Employee'>کارکوونکی</a> </th>
      <th><a href='Sale'>پروشات</a></th>
      <th><a href='Departement'>د کمپنی بخشونه</a></th>
      <th>   <a href='Expenses'>مصارف</a></th>
</tr>
</table>
 

<form action="\store3" method="POST" align="center" style="background-color:DarkSlateGray ">  
  <?php echo csrf_field(); ?>
  <h1 style="color:OldLace " align="center">  Bill insert part  </h1> 
         <div class="form-group-mb-3">
                 <lable> DrugName </lable><br>
                 <input type="text" name="DrugName" class="form-control">
                 </div>   
         <div class="form-group-mb-3">
                 <lable> Quantity </lable><br>
                 <input type="number" name="Quantity" class="form-control">
                 </div> 
         <div class="form-group-mb-3">
                 <lable> Price </lable><br>
                 <input type="number" name="Price" class="form-control">
                 </div> 
         <div class="form-group-mb-3">
                 <lable> Descount </lable><br>
                 <input type="number" name="Descount" class="form-control">
                 </div> 
         <div class="form-group-mb-3">
                 <lable> Total</lable><br>
                 <input type="number" name="Total" class="form-control">
                 </div> 
         <div class="form-group-mb-3">
                 <lable> Data </lable><br>
                 <input type="date" name="Date" class="form-control">
                 </div>    
  
  <button style="width:7%;background-color:Magenta " type="submit"  name="save" class="btn btn-primary"> Save</button>
  </form>



<form style="background-color:gray" >
<h1   align="center">Bills show part  </h1>
<table  style="width:95%"  align="center">
    <tr>
         <th>ID</th>
         <th>DrugName</th>
         <th>Quantity</th>
         <th>Price</th>
         <th>Total</th>
         <th>Descount</th>
         <th>Date</th>
         <th>Edit row</th>
         <th>Delete row</th>
    </tr>
     <?php $__currentLoopData = $Bill; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
           <td><?php echo e($item->id); ?></td>
           <td><?php echo e($item->DrugName); ?></td>
           <td><?php echo e($item->Quantity); ?></td>
           <td><?php echo e($item->Price); ?></td>
           <td><?php echo e($item->Total); ?></td>
           <td><?php echo e($item->Descount); ?></td>
           <td><?php echo e($item->Date); ?></td>
           <td>
 <a href="<?php echo e(url('Bill_Edit/'.$item->id)); ?>" class="btn btn-primary btn-sm">Edit</a>     
           </td>
           <td>
 <a href=" url('Bill_Delete/'.$item->id) }}" class="btn btn_danger btn_sm">Delete</a>
           </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
      </table> 
 </form>     
</body><?php /**PATH C:\LaravelProject\mylaravel\resources\views/Bill.blade.php ENDPATH**/ ?>