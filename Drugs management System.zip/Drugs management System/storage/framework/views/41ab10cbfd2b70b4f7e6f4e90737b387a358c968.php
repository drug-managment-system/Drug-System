<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    width:35%;
    border-collapse: collapse;}
th, td {
    padding:  5px;}
</style>
</head>
<br>  <h1   align="center"> Now you can Edit this $Employee<br>___________________________________________________________</h1>
<body style="background-color:lightgrey" >
 
 
<form action="<?php echo e(url('update-Emp/'.$Employee->id)); ?>" method="POST">

<?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
      
          
    
   
    <table  align="center">  
            <tr>
             <td>
          
                    <label  for="">Emp Name . . . . . . .  . . .</label>
                    <input type="text" name="Name" value="<?php echo e($Employee->Name); ?>" class="form-control">
                    </td>
                 </tr>
                 <tr>
                    <td>
                   <label for="">Email . . . . . . . . . . . . . .</label>
    
                   <input type="text" name="Email" value="<?php echo e($Employee->Email); ?>" class="form-control">
                    </td> 
                    </tr>
                    <td>
                    <label for="">Address . . . . . . . . . . . . </label>
                    <input type="text" name="Address" value="<?php echo e($Employee->Address); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                    <label for="">Emp Job   . . . . . . . . . . . . </label>
                    <input type="text" name="Job" value="<?php echo e($Employee->Job); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                    <label for="">FatherName . . . . . . . . . . </label>
                    <input type="text" name="FatherName" value="<?php echo e($Employee->FatherName); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">Salary .. . . . . . . . . . . . . . </label>
                   <input type="number" name="Salary" value="<?php echo e($Employee->Salary); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">IncomeDate . . . . . . . . . . </label>
                   <input type="date" name="IncomeDate" value="<?php echo e($Employee->IncomeDate); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">DepID . . . . . . . . . . . . . . </label>
                   <input type="number" name="DepID" value="<?php echo e($Employee->DepID); ?>" class="form-control">
                </td>
                    </tr> 
                    </table> 
                    
             
          <br> <div class="form-group mb-3" align="center">
           <button type="submit" class="btn btn-primary"  style="background-color:green">Update</button>
          </div> 
         <h1 align="center" >___________________________________________________________</h1> 
                   
         </form>                       
 
 <?php /**PATH E:\Final Project\mylaravel\resources\views/Emp_Edit.blade.php ENDPATH**/ ?>