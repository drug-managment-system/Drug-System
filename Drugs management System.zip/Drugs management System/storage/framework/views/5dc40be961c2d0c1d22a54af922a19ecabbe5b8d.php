<body style="background-color:lightgrey">
        <h1   align="center">Now you can add new customer </h1> 

          <form class="col-md-12"   action="\store2" method="POST" align="center" >
          <?php echo csrf_field(); ?>
          
        
          <div  style="margin:40px;" align="right" > <a href='Customer' style="background-color:green"  >GO Back</a> </div>
         
          <lable> Name </lable><br>
                <input type="text" name="Name" class="form-control" style="width:70%" > <br><br>

                     <lable> FatherName </lable><br>
              <input type="text" name="FatherName" class="form-control" style="width:70%"> <br><br>

                     <lable> Email </lable> <br> 
                <input type="text" name="Email" class="form-control" style="width:70%"> <br><br> 

                     <lable> Address </lable> <br> 
                <input type="text" name="Address" class="form-control" style="width:70%"> <br><br>
                   
           
                  <button style="width:10%;background-color:Magenta " type="submit"  name="save" class="btn btn-primary"> Save</button>
            </div>
               </form>
               </body><?php /**PATH E:\Final Project\mylaravel\resources\views/\AddCustomer.blade.php ENDPATH**/ ?>