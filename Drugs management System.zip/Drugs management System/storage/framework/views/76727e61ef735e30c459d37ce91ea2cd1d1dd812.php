    <form action="<?php echo e(url('update-Emp/'.$Employee->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group mb-3">
                            <label for="">Name</label>
                            <input type="text" name="Name" value="<?php echo e($Employee->Name); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Email</label>
                            <input type="text" name="Emaill" value="<?php echo e($Employee->Email); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Address</label>
                            <input type="text" name="Address" value="<?php echo e($Employee->Address); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">State</label>
                            <input type="text" name="State" value="<?php echo e($Employee->State); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">FatherName</label>
                            <input type="text" name="FatherName" value="<?php echo e($Employee->FatherName); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <label for="">Salary</label>
                            <input type="number" name="Salary" value="<?php echo e($Employee->Salary); ?>" class="form-control">
                        </div>
                        <div class="form-group mb-3">
                            <button type="submit" class="btn btn-primary">Update Employee</button>
                        </div>

                    </form>


                    
<?php /**PATH E:\Computer Science  Faculty Data and Information 1\8 Semester Data\mylaravel\resources\views/Emp_Edit.blade.php ENDPATH**/ ?>