<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    width:30%;
    border-collapse: collapse;}
th, td {
    padding:  5px;}
</style>
</head>
<br>  <h1   align="center"> Now you can Edit $Money<br>___________________________________________________________</h1>
<body style="background-color:lightgrey" >
 
<form action="<?php echo e(url('update-Money/'.$Money->id)); ?>" method="POST">

<?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
      
          
 
    <table  align="center">  
            <tr>
             <td>
          <label for="" align="rigth">Total_Blance . . . .</label>
          <input type="number" name="Total_Blance" value="<?php echo e($Money->Total_Blance); ?>" class="form-control">
                     </td>
                     </tr>
                     <tr>
                    <td>
                    <label  for="">Cash . . . . . . . . . . .</label>
                    <input type="number" name="Cash" value="<?php echo e($Money->Cash); ?>" class="form-control">
                    </td>
                 </tr>
                 <tr>
                    <td>
                   <label for="">Bill_ID . . . . . . . . .</label>
                   <input type="number" name="Bill_ID" value="<?php echo e($Money->Bill_ID); ?>" class="form-control">
                    </td> 
                    </tr>
                    <td>
                    <label for="">Pre_Blance  . . . . . . </label>
                    <input type="number" name="Pre_Blance" value="<?php echo e($Money->Pre_Blance); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                    <label for="">Loan    . . . . . . . . . . . </label>
                    <input type="number" name="Loan" value="<?php echo e($Money->Loan); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                    <label for="">Date . . . . . . . . . . . </label>
                   <label for=""> </label>
                   <input type="date" name="Date" value="<?php echo e($Money->Date); ?>" class="form-control">
                </td>
                    </tr> 
                  
                    </table> 
                    
             
          <br> <div class="form-group mb-3" align="center">
           <button type="submit" class="btn btn-primary"  style="background-color:green">Update</button>
          </div> 
         <h1 align="center" >___________________________________________________________</h1> 
                   
         </form>                       
 





 












                     
         
                        
                        
                       
                    
<?php /**PATH E:\Final Project\mylaravel\resources\views/Money_Edit.blade.php ENDPATH**/ ?>