<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;}
th, td {
    padding: 1px;}
</style>
</head>
<body style="background-color:lightgrey">
  

 <h1   align="center">Departement page  </h1>      
<table   style="width:100%"  align="center">
 <tr>
      <th><a href='Customer'>مشتریان</a></th>
      <th><a href='Stock'>درمل</a> </th>
      <th><a href='Bills'>بیلونه</a> </th>
      <th><a href='Sale'>پروشات</a></th>
      <th><a href='Employees' >کارکوونکی</a></th>
      <th>   <a href='Expenses'>مصارف</a></th>
      <th><a href='index'>Home</a> </th>
</tr>
</table>
 

<form action="\store4" method="POST" align="center" style="background-color:DarkSlateGray ">  
  <?php echo csrf_field(); ?>
  <h1 style="color:OldLace " align="center"> Departement insert part  </h1> 
         <div class="form-group-mb-3">
                 <lable> Departement Name </lable><br>
                 <input type="text" name="DepartementName" class="form-control">
                 </div>   
         
  
  <button style="width:7%;background-color:Magenta " type="submit"  name="save" class="btn btn-primary"> Save</button>
  </form>



<form style="background-color:gray" >
<h1   align="center">Departemnt show part  </h1>
<table  style="width:95%"  align="center">
    <tr>
         <th>ID</th>
         <th>DepartementName</th>
         <th>Edit row</th>
         <th>Delete row</th>
    </tr>
     <?php $__currentLoopData = $Departement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
           <td><?php echo e($item->id); ?></td>
           <td><?php echo e($item->DepartementName); ?></td>
           
           <td>
 <a href="<?php echo e(url('Dep_Edit/'.$item->id)); ?>" class="btn btn-primary btn-sm">Edit</a>     
           </td>
           <td>
 <a href=" url('Dep_Delete/'.$item->id) }}" class="btn btn_danger btn_sm">Delete</a>
           </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
      </table> 
 </form>     
</body><?php /**PATH C:\LaravelProject\mylaravel\resources\views/Departement.blade.php ENDPATH**/ ?>