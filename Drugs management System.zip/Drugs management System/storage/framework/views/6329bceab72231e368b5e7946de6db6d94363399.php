<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;}
th, td {
    padding: 1px;}
</style>
</head>
<body style="background-color:lightgrey">
  

 <h1   align="center">Employees page  </h1>      
<table   style="width:100%"  align="center">
 <tr>
      <th><a href='Custome'>مشتریان</a></th>
      <th><a href='Stock'>درمل</a> </th>
      <th><a href='Bill'>بیلونه</a> </th>
      <th><a href='Sale'>پروشات</a></th>
      <th><a href='Departement'>د کمپنی بخشونه</a></th>
      <th>   <a href='Expenses'>مصارف</a></th>
</tr>
</table>
 

<form action="\store" method="POST" align="center" style="background-color:DarkSlateGray ">  
  <?php echo csrf_field(); ?>
  <h1 style="color:OldLace " align="center">  Employees insert part  </h1> 
         <div class="form-group-mb-3">
                 <lable> Employee Name </lable><br>
                 <input type="text" name="Name" class="form-control">
                 </div>   
         <div class="form-group-mb-3">
                 <lable> Employee FatherName </lable><br>
                 <input type="text" name="FatherName" class="form-control">
                 </div> 
         <div class="form-group-mb-3">
                 <lable> Employee Emaill </lable><br>
                 <input type="text" name="Emaill" class="form-control">
                 </div> 
         <div class="form-group-mb-3">
                 <lable> Employee Address </lable><br>
                 <input type="text" name="Address" class="form-control">
                 </div> 
         <div class="form-group-mb-3">
                 <lable> Salary </lable><br>
                 <input type="number" name="Salary" class="form-control">
                 </div> 
         <div class="form-group-mb-3">
                 <lable> Employee State </lable><br>
                 <input type="text" name="State" class="form-control">
                 </div>    
  
  <button style="width:7%;background-color:Magenta " type="submit"  name="save" class="btn btn-primary"> Save</button>
  </form>



<form style="background-color:gray" >
<h1   align="center">Employees insert part  </h1>
<table  style="width:95%"  align="center">
    <tr>
         <th>ID</th>
         <th>Name</th>
         <th>FahterName</th>
         <th>Address</th>
         <th>Email</th>
         <th>Salary</th>
         <th>State</th>
         <th>Edit row</th>
         <th>Delete row</th>
    </tr>
     <?php $__currentLoopData = $Employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
           <td><?php echo e($item->id); ?></td>
           <td><?php echo e($item->Name); ?></td>
           <td><?php echo e($item->FatherName); ?></td>
           <td><?php echo e($item->Address); ?></td>
           <td><?php echo e($item->Email); ?></td>
           <td><?php echo e($item->Salary); ?></td>
           <td><?php echo e($item->State); ?></td>
           <td>
 <a href="<?php echo e(url('Emp_Edit/'.$item->id)); ?>" class="btn btn-primary btn-sm">Edit</a>     
           </td>
           <td>
 <a href=" url('Emp_Delete/'.$item->id) }}" class="btn btn_danger btn_sm">Delete</a>
           </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
      </table> 
 </form>     
</body><?php /**PATH C:\LaravelProject\mylaravel\resources\views/indexx.blade.php ENDPATH**/ ?>