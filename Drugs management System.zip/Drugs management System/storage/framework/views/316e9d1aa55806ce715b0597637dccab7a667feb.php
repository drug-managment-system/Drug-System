<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    width:30%;
    border-collapse: collapse;}
th, td {
    padding:  2px;}
</style>
</head>
 
<body style="background-color:lightgrey" >
 
<form action="<?php echo e(url('update-Bill/'.$Bill->id)); ?>" method="POST">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
      
          
<h1   align="center"> Now you can Edit This Bill<br>___________________________________________________________</h1>  
 
   
    <table  align="center">  
            <tr>
             <td>
          <label for="" align="rigth">DrugName . . . . . . .</label>
          <input type="text" name="DrugName" value="<?php echo e($Bill->DrugName); ?>" class="form-control">
                     </td>
                     </tr>
                     <tr>
                    <td>
                    <label  for="">Quantity . . . . . .  . . .</label>
                    <input type="number" name="Quantity" value="<?php echo e($Bill->Quantity); ?>" class="form-control">
                    </td>
                 </tr>
                 <tr>
                    <td>
                   <label for="">Price . . . . . . . . . . . .</label>
    
                   <input type="number" name="Price" value="<?php echo e($Bill->Price); ?>" class="form-control">
                    </td> 
                    </tr>
                    <td>
                    <label for="">Total . . . . . . . . . . . . </label>
                   
                    <input type="number" name="Total" value="<?php echo e($Bill->Total); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                    <label for="">Discount    . . . . . . . . . </label>
   
                    <input type="number" name="Discount" value="<?php echo e($Bill->Discount); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                    <label for="">Cash . . . . . . . . . . . . </label>
                    <input type="number" name="Cash" value="<?php echo e($Bill->Cash); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">Dilevared_By . . .. . </label>
                 
                   <input type="text" name="Dilevared_By" value="<?php echo e($Bill->Dilevared_By); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">Stock_ID .  . . . . .  . . </label>
                 
                   <input type="number" name="Stock_ID" value="<?php echo e($Bill->Stock_ID); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">Pre_Blance . . . . . . .  </label>
                 
                   <input type="number" name="Pre_Blance" value="<?php echo e($Bill->Pre_Blance); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">Customer_ID  . . . . . </label>
                 
                   <input type="number" name="Customer_ID" value="<?php echo e($Bill->Customer_ID); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">Loan . . . . . . . . . . . . </label>
                 
                   <input type="number" name="Loan" value="<?php echo e($Bill->Loan); ?>" class="form-control">
                </td>
                    </tr> 
                    </tr>
                    <td>
                   <label for="">Date . . . . . . . . . . . . </label>
                 
                   <input type="date" name="Date" value="<?php echo e($Bill->Date); ?>" class="form-control">
                </td>
                    </tr> 
                    </table> 
                    
             
          <br> <div class="form-group mb-3" align="center">
           <button type="submit" class="btn btn-primary"  style="background-color:green">Update</button>
          </div> 
         <h1 align="center" >___________________________________________________________</h1> 
                   
         </form>                       
 


 <?php /**PATH E:\Final Project\mylaravel\resources\views/Bill_Edit.blade.php ENDPATH**/ ?>