<!DOCTYPE html>
<thml lan="en">
<head>
<title>Employee Management</title>
<meta charset="utp-8">
</head>
<body style="background-color:lightgrey">
<div class="container">
<form action="\Empinsert" method="POST" class="form-group" >
<?php echo csrf_field(); ?>


<div style="background-color:gray; color:white; padding:10px;width:20%;">
 
<lable >Name</lable><br>
<input type="text" name="Name" placeholder="Enter Full Name" class="form-control"><br>
<lable>FatherName</lable><br>
 <input type="text" name="FathrName" placeholder="Enter Father Name" class="form-control"> <br>
<lable>Address</lable><br>
<input type="text" name="Address" placeholder="Enter Address" class="form-control"><br>  
 <lable>Salary</lable><br>
  <input type="number" name="Salary" placeholder="Enter Salary" class="form-control"><br>  
  <lable>Email</lable> <br>
  <input type="text" name="Email" placeholder="Enter Email" class="form-control"> <br>
  <lable>State</lable> <br>
  <input type="text" name="State" placeholder="Enter Emp State" class="form-control"> <br><br>
 <button type="submit" value="Save" name="btnSave" class="btn btn-primary">Submit</button>
</div>



</form>
</div>
</body>
</html><?php /**PATH C:\LaravelProject\mylaravel\resources\views/Employee.blade.php ENDPATH**/ ?>